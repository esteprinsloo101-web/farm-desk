# Farm ops cadence (quick)

1. Put fert / graze / inject-reminder / repair on Today via ProcessRunner — not a rebuilt spreadsheet.
2. Inject reminders = schedule only. Confirm product and dose with your vet.
3. Keep supplier / vet WhatsApp links in Contacts; open from the wizard.
4. Export JSON after a clean week for phone restore.
5. Weather module is seasonal notes in v1 — not a live frost alert.
