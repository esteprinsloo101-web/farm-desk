# Farm Desk — unlock pack

**Faceless Plain Desk** · soft-launch unlock (suggested **R199**)

Free live demo (sample data): https://esteprinsloo101-web.github.io/farm-desk/

## What’s in this zip
- `app/` — full offline installable PWA
- `SETUP.md` — open locally, install, farm loops, backup
- `DISCLAIMER.md` — legal fence (read before use) — not vet
- `sample/sample-import.json` — demo sample for Import practice
- `guides/ops-cadence.md` — short tip sheet (ops only, no prescriptions)

## Soft shop note
Stokvel pack https://stofficial.gumroad.com/l/ydbgne remains the primary public CTA until first ZAR. Garage Desk and Welgelegen Farm Desk are never sellable.
